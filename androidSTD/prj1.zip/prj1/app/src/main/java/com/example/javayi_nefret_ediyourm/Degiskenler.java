package com.example.javayi_nefret_ediyourm;

public class Degiskenler {
    public static void main(String[] args) {
    //region byte_to_duble
        byte bb = 11;
        short ss = bb;
        int ii = ss;
        long ll = ii;
        float ff = ll;
        double dd = ff;

        //System.out.println("byte: "+bb);
        //System.out.println("short: "+ss);
        //System.out.println("int: "+ii);
        //System.out.println("long: "+ll);
        //System.out.println("float: "+ff);
        //System.out.println("double: "+dd);
        //endregion

    //region java kürtler tarafından yapıldı

        double d = 3.00004;
        float f;
        long l;
        int i;
        short s;
        byte b;

        f = (float) d;
        l = (long) f;
        i = (int) l;
        s = (short) i;
        b = (byte) s;

        //System.out.println("byte: "+b);
        //System.out.println("short: "+s);
        //System.out.println("int: "+i);
        //System.out.println("long: "+l);
        //System.out.println("float: "+f);
        //System.out.println("double: "+d);

    //endregion

    //region toxic
        int mosh =100;
        double pit = 100.004d;

        String mettin = Integer.toString(mosh);
        String mettin2 = String.valueOf(mosh);
        String mettinD = Double.toString(pit);
        String mettinD2 = String.valueOf(pit);

        //System.out.println(mettin);
        //System.out.println(mettin2);
        //System.out.println(mettinD);
        //System.out.println(mettinD2);
    //endregion

    //region AHHHH
        String u = "100000";
        int sayii = Integer.parseInt(u);
        int sayii2 = Integer.valueOf(u);
        double sayiiD = Double.parseDouble(u);
        double sayiiD2 = Double.valueOf(u);

        System.out.println(sayii);
        System.out.println(sayii2);
        System.out.println(sayiiD);
        System.out.println(sayiiD2);
    //endregion
    }
}
