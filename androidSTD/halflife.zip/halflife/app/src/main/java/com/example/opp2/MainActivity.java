 package com.example.opp2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText sayiGiris;
    Switch onay;
    Button hesap;
    TextView sonuc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sayiGiris = findViewById(R.id.sayiGiris);
        onay = findViewById(R.id.onay);
        hesap = findViewById(R.id.hesap);
        sonuc = findViewById(R.id.sonuc);

        //region hesap

        hesap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!onay.isChecked())  {
                    Toast.makeText(MainActivity.this, "Lütfen onaylayınız", Toast.LENGTH_SHORT).show();
                    return;
                }

                String not = sayiGiris.getText().toString();

                if (not.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Lütfen Boş Bırakmayın", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (Integer.parseInt(not) >= 50) {
                    sonuc.setText("Aldığınız not: " + not + " Başarılı!");
                    Toast.makeText(MainActivity.this, "Başarılı!", Toast.LENGTH_SHORT).show();
                } else {
                    sonuc.setText("Aldığınız not: " + not + " Başarısız!");
                    Toast.makeText(MainActivity.this, "Başarısız!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //endregion
    }
}