package com.example.opp3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText first, second, third;
    Switch onay;
    Button bak;
    TextView sonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //region atama

        first = findViewById(R.id.firstNum);
        second = findViewById(R.id.secondNum);
        third = findViewById(R.id.thirdNum);
        onay = findViewById(R.id.onay);
        bak = findViewById(R.id.bak);
        sonuc = findViewById(R.id.sonuc);

        //endregion

        //region bul

        bak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!onay.isChecked()) {
                    Toast.makeText(MainActivity.this, "O nay layın!", Toast.LENGTH_SHORT).show();
                    return;
                }

                String one = first.getText().toString();
                String two = second.getText().toString();
                String three = third.getText().toString();

                if (one.isEmpty()||two.isEmpty()||three.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Lütfen seçenekleri boş bırakmayın", Toast.LENGTH_SHORT).show();
                    return;
                }

                int i_one = Integer.parseInt(one);
                int i_two = Integer.parseInt(two);
                int i_three = Integer.parseInt(three);

                if (i_one > i_two&&i_two > i_three) {

                    sonuc.setText("Birinci: " + i_one + ", İkinci: " + i_two + ", Üçüncü: " + i_three);

                } else if (i_two > i_one&& i_one > i_three) {

                    sonuc.setText("Birinci: " + i_two + ", İkinci: " + i_one + ", Üçüncü: " + i_three);

                } else if (i_three > i_two&&i_two > i_one) {

                    sonuc.setText("Birinci: " + i_three + ", İkinci: " + i_two + ", Üçüncü: " + i_one);

                }
            }
        });

        //endregion
    }
}