package com.example.gnx;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    //region whatisthis
    Button hesapla, yeniden;
    EditText boy, kilo;
    LinearLayout ddd, ggg;
    TextView sonuc, cinsiyet, bmi;
    ImageView icon;
    RadioButton erkek, kadin;
    //endregion
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //region isbludeinstein
        hesapla = findViewById(R.id.hesapla);
        yeniden = findViewById(R.id.yeniden);
        boy = findViewById(R.id.inp_boy);
        kilo = findViewById(R.id.inp_kilo);
        ddd = findViewById(R.id.durum);
        ggg = findViewById(R.id.kofte);
        sonuc = findViewById(R.id.out_sonuc);
        cinsiyet = findViewById(R.id.out_cinsiyet);
        bmi = findViewById(R.id.out_bmi);
        icon = findViewById(R.id.efe);
        erkek = findViewById(R.id.radioButton);
        kadin = findViewById(R.id.radioButton2);
        //endregion

        DecimalFormat decimalFormat = new DecimalFormat("0.00");

        hesapla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Integer.parseInt(boy.getText().toString())<=0 || Integer.parseInt(kilo.getText().toString())<=0) {
                    Toast.makeText(MainActivity.this, "Lütfen boy veya kiloyu 0 üzeri bir sayı ile doldurun!", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    ddd.setVisibility(View.GONE);
                    ggg.setVisibility(View.VISIBLE);
                }

                calc();
            }

            private void calc() {
                double iboy, ikilo, ibmi;
                String icinsiyet;
                iboy = Double.parseDouble(boy.getText().toString()) / 100;
                ikilo = Double.parseDouble(kilo.getText().toString());
                ibmi = ikilo / (iboy*iboy);
                if (kadin.isChecked()) {
                    icinsiyet = "Kadın";
                } else { icinsiyet="Erkek"; }

                if(ibmi<18.5) {
                    sonuc.setTextColor(getColor(R.color.underweight));
                    cinsiyet.setTextColor(getColor(R.color.underweight));
                    bmi.setTextColor(getColor(R.color.underweight));

                    sonuc.setText("ZAYIF");
                    cinsiyet.setText(icinsiyet);
                    bmi.setText(String.valueOf(ibmi));
                    icon.setImageResource(R.drawable.underweight);
                } else if(ibmi<25) {
                    sonuc.setTextColor(getColor(R.color.normal));
                    cinsiyet.setTextColor(getColor(R.color.normal));
                    bmi.setTextColor(getColor(R.color.normal));

                    sonuc.setText("NORMAL");
                    cinsiyet.setText(icinsiyet);
                    bmi.setText(String.valueOf(ibmi));
                    icon.setImageResource(R.drawable.normal);
                } else if(ibmi<30) {
                    sonuc.setTextColor(getColor(R.color.overweight));
                    cinsiyet.setTextColor(getColor(R.color.overweight));
                    bmi.setTextColor(getColor(R.color.overweight));

                    sonuc.setText("KİLOLU");
                    cinsiyet.setText(icinsiyet);
                    bmi.setText(String.valueOf(ibmi));
                    icon.setImageResource(R.drawable.overweight);
                } else if(ibmi<35) {
                    sonuc.setTextColor(getColor(R.color.obeze));
                    cinsiyet.setTextColor(getColor(R.color.obeze));
                    bmi.setTextColor(getColor(R.color.obeze));

                    sonuc.setText("OBEZ");
                    cinsiyet.setText(icinsiyet);
                    bmi.setText(String.valueOf(ibmi));
                    icon.setImageResource(R.drawable.obese);
                } else {
                    sonuc.setTextColor(getColor(R.color.extraobese));
                    cinsiyet.setTextColor(getColor(R.color.extraobese));
                    bmi.setTextColor(getColor(R.color.extraobese));

                    sonuc.setText("EKSTRA OBEZ");
                    cinsiyet.setText(icinsiyet);
                    bmi.setText(String.valueOf(ibmi));
                    icon.setImageResource(R.drawable.extremelyobese);
                }
            }
        });

        yeniden.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ddd.setVisibility(View.VISIBLE);
                ggg.setVisibility(View.GONE);
                temizle();
            }

            private void temizle() {
                boy.setText("");
                kilo.setText("");
            }
        });
    }
}